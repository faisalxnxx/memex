<img src=".img.png">

# FBBrute
FBBrute is a Facebook brute force tool, launches an attack by guessing the target password with a set of wordlist provided.  
so this is the same as you try to login to someone's account while guessing the password, if the password you are trying is wrong, you will think of another password that might be used by the target to login to the account but this way might be a bit longer, but with FBBrute this will make it easier.  
you only need to create one file with a collection of passwords then enter the username, email or ID of the target then press start crack...  

### Installation and Using FBBrute
```bash
$ apt-get install python git
$ git clone https://github.com/Gameye98/FBBrute
$ cd FBBrute
$ python fbbrute.py
```

### Contact me
Line      : dtl.lily  
Telegram  : @dtlily  
Facebook  : cgi.izo  
Instagram : @dtlily  